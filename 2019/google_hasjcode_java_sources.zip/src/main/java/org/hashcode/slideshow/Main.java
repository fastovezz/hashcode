package org.hashcode.slideshow;

import org.apache.commons.collections4.SetUtils;

import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.FileReader;
import java.io.FileWriter;
import java.util.*;

public class Main {

    static class Photo {
        int index;
        boolean horizontal;
        Set<String> tags;

        public Photo(int index, boolean horizontal, Set<String> tags) {
            this.index = index;
            this.horizontal = horizontal;
            this.tags = tags;
        }

        @Override
        public boolean equals(Object o) {
            if (this == o) return true;
            if (o == null || getClass() != o.getClass()) return false;
            Photo photo = (Photo) o;
            return index == photo.index;
        }

        @Override
        public int hashCode() {
            return Objects.hash(index);
        }

        @Override
        public String toString() {
            return index + " " + (horizontal ? "H" : "V") + " " + tags;
        }
    }

    static class Slide {
        Photo[] photos;

        Set<String> tags = new HashSet<>();

        public Slide(Photo[] photos) {
            this.photos = photos;

            for (Photo photo : photos) {
                tags.addAll(photo.tags);
            }
        }
    }

    public static int interest(Slide s1, Slide s2) {

        int common = SetUtils.intersection(s1.tags, s2.tags).size();
        int unique1 = SetUtils.difference(s1.tags, s2.tags).size();
        int unique2 = SetUtils.difference(s2.tags, s1.tags).size();

        return Math.min(common, Math.min(unique1, unique2));

    }

    public static List<Photo> readPhotos(String file) throws Exception {
        List<Photo> photos = new ArrayList<>();

        try (BufferedReader reader = new BufferedReader(new FileReader(file))) {
            int count = Integer.parseInt(reader.readLine());

            for (int i = 0; i < count; i++) {
                String[] line = reader.readLine().split(" ");
                boolean horizontal = "H".equals(line[0]);
                int tagsCount = Integer.parseInt(line[1]);
                Set<String> tags = new HashSet<>();

                for (int j = 0; j < tagsCount; j++) {
                    tags.add(line[j + 2]);
                }

                photos.add(new Photo(i, horizontal, tags));
            }
        }

        return photos;
    }

    public static void generate(String file) throws Exception {

        List<Photo> photos = readPhotos(file);

        List<Slide> slides = new ArrayList<>();


        Photo vertical = null;
        int slideCount = 0;

        for (Photo photo : photos) {
            if (photo.horizontal) {
                slides.add(new Slide(new Photo[]{photo}));
                slideCount++;
            } else {
                if (vertical == null) {
                    vertical = photo;
                } else {
                    slides.add(new Slide(new Photo[]{vertical, photo}));
                    slideCount++;
                    vertical = null;
                }
            }
        }


        try (BufferedWriter writer = new BufferedWriter(new FileWriter(file + "__out.txt"))) {

            writer.write(String.valueOf(slideCount));
            writer.newLine();

            for (Slide slide : slides) {

                if (slide.photos.length == 1) {
                    writer.write(String.valueOf(slide.photos[0].index));
                    writer.newLine();
                } else {
                    writer.write(String.valueOf(slide.photos[0].index));
                    writer.write(" ");
                    writer.write(String.valueOf(slide.photos[1].index));
                    writer.newLine();
                }

            }

        }


    }

    public static void main(String[] args) throws Exception {


        generate("a_example.txt");
        generate("b_lovely_landscapes.txt");
        generate("c_memorable_moments.txt");
        generate("d_pet_pictures.txt");
        generate("e_shiny_selfies.txt");


    }

}
