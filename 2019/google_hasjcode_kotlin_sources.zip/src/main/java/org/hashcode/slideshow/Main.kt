package org.hashcode.slideshow

import org.hashcode.slideshow.logic.FileManager
import org.hashcode.slideshow.logic.SlidesGenerator


@Throws(Exception::class)
fun generate(file: String) {
    val slides = SlidesGenerator.generateSlides(file)
    val fileName = "${file}Result.txt"
    FileManager.writeFile(fileName, slides)
}

@Throws(Exception::class)
fun main(args: Array<String>) {
    generate("a_example.txt")
    generate("b_lovely_landscapes.txt")
    generate("c_memorable_moments.txt")
    generate("d_pet_pictures.txt")
    generate("e_shiny_selfies.txt")
}


