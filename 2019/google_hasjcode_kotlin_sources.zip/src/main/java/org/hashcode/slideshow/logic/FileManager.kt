package org.hashcode.slideshow.logic

import org.apache.commons.collections4.SetUtils
import org.hashcode.slideshow.model.Photo
import org.hashcode.slideshow.model.Slide
import java.io.BufferedReader
import java.io.BufferedWriter
import java.io.FileReader
import java.io.FileWriter
import java.util.*
import java.util.logging.Level
import java.util.logging.Logger

object FileManager {

    @Throws(Exception::class)
    fun readPhotos(file: String): List<Photo> {
        val photos = ArrayList<Photo>()

        BufferedReader(FileReader(file)).use { reader ->
            val count = Integer.parseInt(reader.readLine())

            for (i in 0 until count) {
                val line = reader.readLine().split(" ".toRegex()).dropLastWhile { it.isEmpty() }.toTypedArray()
                val horizontal = "H" == line[0]
                val tagsCount = Integer.parseInt(line[1])
                val tags = HashSet<String>()

                for (j in 0 until tagsCount) {
                    tags.add(line[j + 2])
                }

                photos.add(Photo(i, horizontal, tags))
            }
        }

        return photos
    }


    fun writeFile(fileName: String, slides: List<Slide>) {
        var totalScores = 0
        BufferedWriter(FileWriter(fileName)).use { writer ->

            writer.write(slides.size.toString())
            writer.newLine()

            var previous: Slide? = null
            for (slide in slides) {

                previous?.let { totalScores += interestRate(it, slide) }
                previous = slide
                if (slide.photos.size == 1) {
                    writer.write(slide.photos[0].index.toString())
                    writer.newLine()
                } else {
                    writer.write(slide.photos[0].index.toString())
                    writer.write(" ")
                    writer.write(slide.photos[1].index.toString())
                    writer.newLine()
                }

            }
        }
        Logger.getGlobal().log(Level.INFO, "totalScores:$totalScores")
    }

    fun interestRate(s1: Slide, s2: Slide): Int {
        val common = SetUtils.intersection(s1.tags, s2.tags).size
        val unique1 = SetUtils.difference(s1.tags, s2.tags).size
        val unique2 = SetUtils.difference(s2.tags, s1.tags).size

        return Math.min(common, Math.min(unique1, unique2))
    }
}