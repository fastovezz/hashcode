package org.hashcode.slideshow.logic

import org.hashcode.slideshow.model.Photo
import org.hashcode.slideshow.model.Slide
import java.util.*

object SlidesGenerator {


    fun generateSlides(file: String): List<Slide> {
        val photos = FileManager.readPhotos(file)

        val slides = ArrayList<Slide>()

        var vertical: Photo? = null

        for (photo in photos) {
            if (photo.horizontal) {
                slides.add(Slide(arrayOf(photo)))
            } else {
                if (vertical == null) {
                    vertical = photo
                } else {
                    slides.add(Slide(arrayOf(vertical, photo)))
                    vertical = null
                }
            }
        }
        return slides
    }
}