package org.hashcode.slideshow.model

import java.util.*

class Photo(var index: Int, var horizontal: Boolean, var tags: Set<String>) {

    override fun equals(o: Any?): Boolean {
        if (this === o) return true
        if (o == null || this::class.java != o::class.java) return false
        val photo = o as Photo?
        return index == photo!!.index
    }

    override fun hashCode(): Int {
        return Objects.hash(index)
    }

    override fun toString(): String {
        return index.toString() + " " + (if (horizontal) "H" else "V") + " " + tags
    }
}