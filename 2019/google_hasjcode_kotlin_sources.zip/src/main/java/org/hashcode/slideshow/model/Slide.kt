package org.hashcode.slideshow.model

import java.util.*


class Slide(var photos: Array<Photo>) {

    var tags: MutableSet<String> = HashSet()

    init {
        for (photo in photos) {
            tags.addAll(photo.tags)
        }
    }
}